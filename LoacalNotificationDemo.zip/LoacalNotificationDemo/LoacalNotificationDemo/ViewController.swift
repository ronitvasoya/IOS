//
//  ViewController.swift
//  LoacalNotificationDemo
//
//  Created by TOPS on 11/19/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        initNotificationsatapcheck()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func initNotificationsatapcheck() {
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) { (success, error) in
            
            if success
            {
                print("Success")
            }
            else
            {
                print("Error")
            }
        }
    }
    
    @IBAction func CreateNotification(_ sender: Any) {
        
        let notification = UNMutableNotificationContent()
        
        notification.title = "Good Morning"
        
        notification.subtitle = "Somtime this way comes"
        notification.body = "I need to tel you somthing"
        
        let notificationtrigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        
        let request = UNNotificationRequest(identifier: "Notification", content: notification, trigger: notificationtrigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

