//
//  ArtiestModel.swift
//  firebasedbDemo
//
//  Created by TOPS on 11/21/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ArtiestModel: NSObject {
    
    var id: String?
    var name: String?
    var age: String?
    
    init(id: String?, name: String?, age: String?){
        self.id = id
        self.name = name
        self.age = age
    }
}
