//
//  ViewController.swift
//  SharingDemo
//
//  Created by TOPS on 11/19/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func Share(_ sender: Any) {
        
        var arr:[Any] = []
        
        arr.append("This is tops")
        
        let alt = UIActivityViewController(activityItems: arr, applicationActivities: nil)
        
        self.present(alt, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

