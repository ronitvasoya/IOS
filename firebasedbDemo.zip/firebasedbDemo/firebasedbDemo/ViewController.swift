//
//  ViewController.swift
//  firebasedbDemo
//
//  Created by TOPS on 11/21/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtage: UITextField!
    
    var artistList = [ArtiestModel]()
    var refArtists: DatabaseReference!
    var selectkey:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        refArtists = Database.database().reference().child("artists");

        getdata()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnupdate(_ sender: Any) {
    
        if selectkey != ""
        {
            let artlist = ["id":selectkey,"name":txtname.text! as String,"age":txtage.text! as String]
            
            refArtists.child(selectkey).setValue(artlist);
            
            getdata()
            
        }
    
    }
    @IBAction func btninsert(_ sender: Any) {
        
        let key = refArtists.childByAutoId().key
        
        let artlist = ["id":key,"name":txtname.text! as String,"age":txtage.text! as String]
        
        refArtists.child(key).setValue(artlist);
        
        getdata()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return artistList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        //the artist object
        let artist: ArtiestModel
        
        //getting the artist of selected position
        artist = artistList[indexPath.row]
        
        //adding values to labels
        cell.textLabel?.text = artist.name
        cell.detailTextLabel?.text = artist.age
        //returning cell
        return cell

        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let artist: ArtiestModel
        
        //getting the artist of selected position
        artist = artistList[indexPath.row]
        
        txtname.text = artist.name
        txtage.text = artist.age
        selectkey = artist.id!
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let artist: ArtiestModel
        
        //getting the artist of selected position
        artist = artistList[indexPath.row]
        
        refArtists.child(artist.id!).removeValue()
        getdata()
        
    }
    
    func getdata(){
        
        refArtists.observe(DataEventType.value, with: { (snapshot) in
            
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.artistList.removeAll()
                
                //iterating through all the values
                for artists in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let artistObject = artists.value as? [String: AnyObject]
                    let artistName  = artistObject?["name"]
                    let artistId  = artistObject?["id"]
                    let artistage = artistObject?["age"]
                    
                    //creating artist object with model and fetched values
                    let artist = ArtiestModel(id: artistId as! String?, name: artistName as! String?, age: artistage as! String?)
                    
                    //appending it to list
                    self.artistList.append(artist)
                }
                
                //reloading the tableview
                self.tbl.reloadData()
            }
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

