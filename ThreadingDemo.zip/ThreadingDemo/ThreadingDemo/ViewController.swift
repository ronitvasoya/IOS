//
//  ViewController.swift
//  ThreadingDemo
//
//  Created by TOPS on 11/19/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView?
    
    @IBOutlet weak var img3: UIImageView!
    
    @IBOutlet weak var img4: UIImageView!
    
    var queue = OperationQueue()
    
    let imageUrl = ["https://images.unsplash.com/photo-1514282401047-d79a71a590e8?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=ishan-seefromthesky-490967-unsplash.jpg&s=d27c100c1f938a2dd9b72e48b103df05","https://images.unsplash.com/photo-1444760134166-9b8f7d0fc038?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=davide-ragusa-38945-unsplash.jpg&s=505e05f51859a9fb791b3315b8adcd9c","https://images.unsplash.com/photo-1487837647815-bbc1f30cd0d2?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=max-ostrozhinskiy-212676-unsplash.jpg&s=ed3d636702176d52d61539c139422b1d","https://images.unsplash.com/photo-1496938884040-e0456a8512ca?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=tim-gouw-280702-unsplash.jpg&s=79523d2dc039a024bd04ff56d3bf7f75"]
    
    class Downloader
    {
        class func downloadImageWithUrl(url:String) -> UIImage! {
            
          var data = Data()
            
            do
            {
                data = try! Data(contentsOf: URL(string: url)!)
            }
            catch
            {
                return nil
            }
            return UIImage(data: data)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func operationQueue(_ sender: Any) {
        
        queue = OperationQueue()
        
        let operation1 = BlockOperation(block: {
        
            let image1 = Downloader.downloadImageWithUrl(url: self.imageUrl[0])
            OperationQueue.main.addOperation({ 
                self.img1.image = image1
            })
        })
        queue.addOperation(operation1)
        
        let operation2 = BlockOperation(block: {
            
            let image2 = Downloader.downloadImageWithUrl(url: self.imageUrl[1])
            OperationQueue.main.addOperation({
                self.img2?.image = image2
            })
        })
        
        operation2.addDependency(operation1)
        queue.addOperation(operation2)
        
        let operation3 = BlockOperation(block: {
            
            let image3 = Downloader.downloadImageWithUrl(url: self.imageUrl[2])
            OperationQueue.main.addOperation({
                self.img3.image = image3
            })
        })
        
        operation3.addDependency(operation2)
        queue.addOperation(operation3)
        
        let operation4 = BlockOperation(block: {
            
            let image4 = Downloader.downloadImageWithUrl(url: self.imageUrl[3])
            OperationQueue.main.addOperation({
                self.img4.image = image4
            })
        })
        
        operation4.addDependency(operation3)
        queue.addOperation(operation4)
    }
    
    @IBAction func cancel(_ sender: Any) {
        
        queue.cancelAllOperations()
    }
    @IBAction func serialQueue(_ sender: Any) {
        
        let serialQueue = DispatchQueue(label: "com.appcode.imageQuueu", attributes: [])
        
        serialQueue.async { () -> Void in
            
            let image1 = Downloader.downloadImageWithUrl(url: self.imageUrl[0])
            DispatchQueue.main.async(execute: {
            
            self.img1.image = image1
        })
        }
        
        serialQueue.async { () -> Void in
            
            let image2 = Downloader.downloadImageWithUrl(url: self.imageUrl[
                1])
            DispatchQueue.main.async(execute: {
                
                self.img2?.image = image2
            })
        }
        
        serialQueue.async { () -> Void in
            
            let image3 = Downloader.downloadImageWithUrl(url: self.imageUrl[2])
            DispatchQueue.main.async(execute: {
                
                self.img3.image = image3
            })
        }
        
        serialQueue.async { () -> Void in
            
            let image4 = Downloader.downloadImageWithUrl(url: self.imageUrl[
                3])
            DispatchQueue.main.async(execute: {
                
                self.img4.image = image4
            })
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

