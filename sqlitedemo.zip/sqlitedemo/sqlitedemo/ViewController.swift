//
//  ViewController.swift
//  sqlitedemo
//
//  Created by TOPS on 10/11/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtempid: UITextField!
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let db = dbclass();
        
        var arr = db.getdata(strquery: "select * from tblemp");
        
        print(arr); 
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclick(_ sender: Any) {
        
        let query = "insert into tblemp(emp_id,emp_name,emp_add)values('\(txtempid.text!)','\(txtempname.text!)','\(txtempadd.text!)')";
        
        let db = dbclass();
        
        let st = db.dml(query: query);
        
        if st == true {
            
            print("inserted");
        }
        else
        {
            print("not");
            
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

